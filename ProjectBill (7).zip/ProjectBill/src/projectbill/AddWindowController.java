package projectbill;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.FileWriter;
import java.io.IOException;

public class AddWindowController {

    @FXML
    private TextField amount;

    @FXML
    private ComboBox<String> category;

    @FXML
    private TextField date;

    @FXML
    private TextField serial;


    User user = SigninWindowController.user;



    public void initialize() {
        category.getItems().addAll("Appropriation bill",
                "Tax bill",
                "Budget bill",
                "Regulatory bill",
                "Social welfare bill",
                "Criminal justice bill",
                "Environmental bill",
                "Trade bill",
                "Infrastructure bill",
                "Education bill");
    }

    @FXML
    void addBillAction(ActionEvent event) {

        String choice = category.getValue();



        if (choice.isEmpty() || amount.getText().isEmpty() || date.getText().isEmpty() || serial.getText().length() != 6)
        {

            JOptionPane.showMessageDialog(null, "Enter all fields,\nSerial must be 6 chars");


        }else {


            System.out.println("Enter bill category:");
            String category = choice;
            System.out.println("Enter bill amount:");
            double amountNum = Double.parseDouble(amount.getText());

            String serialNum = serial.getText();
            System.out.println("Enter bill due date (yyyy-mm-dd):");
            String dueDate = date.getText();

            Bill bill = new Bill(category, amountNum,serialNum ,dueDate);
            try {
                FileWriter writer = new FileWriter("bills.txt", true);
                writer.write(user.getId() + "," + bill.toString() + "\n");
                writer.close();
                JOptionPane.showMessageDialog(null, "Bill added successfully.");


                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("MenuWindow.fxml"));
                    Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
                    Scene scene = new Scene(loader.load());
                    stage.setScene(scene);

                } catch (IOException io) {
                    System.out.println("FXML Loading Error");
                }

            } catch (IOException e) {
                System.out.println("Error occurred while writing to file: " + e.getMessage());
            }
        }


    }

}
