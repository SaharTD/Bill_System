package projectbill;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.*;

public class DeleteWindowController {

    @FXML
    private TextField serial;

    User user = SigninWindowController.user;

    @FXML
    void deleteAction(ActionEvent event) {

        String serialNumber = serial.getText();
        try {
            File inputFile = new File("bills.txt");
            File tempFile = new File("temp.txt");
            FileReader reader = new FileReader(inputFile);
            BufferedReader bufferedReader = new BufferedReader(reader);
            FileWriter writer = new FileWriter(tempFile);
            BufferedWriter bufferedWriter = new BufferedWriter(writer);
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 5 && parts[0].equals(user.getId())) {
                    Bill bill = Bill.fromString(parts[1]+","+parts[2]+","+parts[3]+","+parts[4]);
                    if (!bill.getSerialNumber().equals(serialNumber)) {
                        bufferedWriter.write(line + "\n");
                    }else {
                        JOptionPane.showMessageDialog(null, "Bill deleted successfully.");
                    }
                }
            }
            reader.close();
            bufferedReader.close();
            bufferedWriter.close();
            writer.close();
            inputFile.delete();
            tempFile.renameTo(inputFile);
            JOptionPane.showMessageDialog(null,"Bill deleted successfully.");
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("MenuWindow.fxml"));
                Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
                Scene scene = new Scene(loader.load());
                stage.setScene(scene);

            } catch (IOException io) {
                System.out.println("FXML Loading Error");
            }
        } catch (IOException e) {
            System.out.println("Error occurred while deleting bill:" + e.getMessage());
            JOptionPane.showMessageDialog(null,"Error occurred while deleting bill");

        }

    }

}
