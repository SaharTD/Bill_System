package projectbill;/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author rosemusalli
 */
// user class
public class User {
    private String username;
    private String id;
    private String age;
    private String email;
    private String password;

    public User(String username, String id, String age, String email, String password) {
        this.username = username;
        this.id = id;
        this.age = age;
        this.email = email;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public String getId() {
        return id;
    }

    public String getAge() {
        return age;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    @Override
    public String toString() {
        return username + "," + id + ","+ age +"," + email +"," + password;
    }

}
