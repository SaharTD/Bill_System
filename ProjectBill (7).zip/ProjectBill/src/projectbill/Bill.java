package projectbill;/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author rosemusalli
 */
// bill class

public class Bill {
    private String serialNumber;
    private String category;
    private double amount;
    private String dueDate;

    public Bill(String category, double amount, String serialNumber , String dueDate) {
        this.serialNumber = serialNumber; // generate unique random serial number
        this.category = category;
        this.amount = amount;
        this.dueDate = dueDate;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public String getCategory() {
       return category;
    }

    public double getAmount() {
        return amount;
    }

    public String getDueDate() {
        return dueDate;
    }

    @Override
    public String toString() {
        return serialNumber +"," + category + ","+ amount + "," + dueDate;
    }


    public static Bill fromString(String str) {
        String[] parts = str.split(",");
        if (parts.length == 4) {
            Bill bill = new Bill(parts[1], Double.parseDouble(parts[2]),parts[0] ,parts[3]);
            return bill;
        } else {
            throw new IllegalArgumentException("Invalid bill string: " + str);
        }
    }
}