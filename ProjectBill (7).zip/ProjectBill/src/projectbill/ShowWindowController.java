package projectbill;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ShowWindowController {

    @FXML
    private ComboBox<String> catogry;

    User user = SigninWindowController.user;

    public void initialize() {
        catogry.getItems().addAll("Appropriation bill",
                "Tax bill",
                "Budget bill",
                "Regulatory bill",
                "Social welfare bill",
                "Criminal justice bill",
                "Environmental bill",
                "Trade bill",
                "Infrastructure bill",
                "Education bill");
    }

    @FXML
    void showBillAction(ActionEvent event) {


        String categoryRes = "";
        String category = catogry.getValue();
        categoryRes += ("Bills in category " + category + ":\n\n");
        try {
            FileReader reader = new FileReader("bills.txt");
            BufferedReader bufferedReader = new BufferedReader(reader);
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                String[] parts = line.split(",");
                System.out.println(parts.length);
                if (parts.length == 5 && parts[0].equals(user.getId())) {
                    Bill bill = Bill.fromString(parts[1]+","+parts[2]+","+parts[3]+","+parts[4]);
                    if (bill.getCategory().equals(category)) {

                        String billString = " Category:  "+ bill.getCategory()+"\n"+
                                "Amount:  "+ bill.getAmount()+"\n"+
                                "Serial:  "+ bill.getSerialNumber()+"\n"+
                                "Due Date:  "+ bill.getDueDate()+"\n";
                        categoryRes +=(billString);
                        System.out.println("yes in");
                    }
                }
                categoryRes +="\n";
            }
            reader.close();

//                    JOptionPane.showMessageDialog(null,categoryRes);

            JOptionPane.showMessageDialog(null, categoryRes);

            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("MenuWindow.fxml"));
                Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
                Scene scene = new Scene(loader.load());
                stage.setScene(scene);

            } catch (IOException io) {
                System.out.println("FXML Loading Error");
            }
        } catch (IOException e) {
            System.out.println("Error occurred while reading from file: " + e.getMessage());
        }

    }

}
