package projectbill;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class SignupWindowController {

    @FXML
    private TextField age;

    @FXML
    private TextField email;

    @FXML
    private TextField id;

    @FXML
    private TextField pass;

    @FXML
    private TextField username;

    @FXML
    void createAction(ActionEvent event) {

        try {
//                    FileWriter writer = new FileWriter("users.txt",true);
            if (email.getText().contains("@") && username.getText().length() > 2 && !(age.getText().length() == 0) && pass.getText().length() > 5 && id.getText().length() > 0) {
//
//                        writer.write(textFieldName.getText()+"\n");
//                        writer.write(textFieldEmail.getText()+"\n");
//                        writer.write(textFieldAge.getText()+"\n");
//                        writer.write(textFieldPass.getText()+"\n");
//                        writer.close();


                User user = new User(username.getText(), id.getText(), age.getText(), email.getText(), pass.getText());

                try {
                    FileWriter writer = new FileWriter("users.txt", true);
                    writer.write(user.toString() + "\n");
                    writer.close();
                    System.out.println("Registration successful.");
                    try {
                        FXMLLoader loader = new FXMLLoader(getClass().getResource("SignInWindows.fxml"));
                        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                        Scene scene = new Scene(loader.load());
                        stage.setScene(scene);

                    } catch (IOException io) {
                        System.out.println("FXML Loading Error");
                    }
                } catch (IOException e) {
                    System.out.println("Error occurred while writing to file: " + e.getMessage());
                }


            } else {

                JOptionPane.showMessageDialog(null, "- email must be with correct format\n" +
                        "- name must be more than 2 character\n" +
                        "- age must not be empty\n" +
                        "- password must be more than 6");

            }

        } catch (Exception e) {
            System.out.println("File error");
        }


    }

    @FXML
    void signinaction(ActionEvent event) {

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("SignInWindows.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loader.load());
            stage.setScene(scene);

        } catch (IOException io) {
            System.out.println("FXML Loading Error");
        }


    }

}
