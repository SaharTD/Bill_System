package projectbill;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class SigninWindowController {

    @FXML
    private TextField idInput;

    @FXML
    private TextField pass;

    static User user;

    @FXML
    void SignInAction(ActionEvent event) {


        Scanner input = new Scanner(System.in);

        System.out.println("Enter ID:");
        System.out.println("Enter password:");
        try {
            FileReader reader = new FileReader("users.txt");
            BufferedReader bufferedReader = new BufferedReader(reader);
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                String[] parts = line.split(",");
                System.out.println(parts.length);
                if (parts.length == 5 && parts[1].equals(idInput.getText()) && parts[4].equals(pass.getText())) {
                    user = new User(parts[0], parts[1], parts[2], parts[3], parts[4]);
                    break;
                }
            }
            reader.close();
        } catch (IOException e) {
            System.out.println("Error occurred while reading from file: " + e.getMessage());
        }
        if (user == null) {
            System.out.println("Invalid ID or password. Please try again.");
        } else {
            System.out.println("Login successful.");
        }

        if(user != null){

            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("MenuWindow.fxml"));
                Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
                Scene scene = new Scene(loader.load());
                stage.setScene(scene);

            } catch (IOException io) {
                System.out.println("FXML Loading Error");
            }

        }else {
            JOptionPane.showMessageDialog(null,"Please Enter the correct information");
        }


    }

    @FXML
    void createAction(ActionEvent event) {

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("SignUpWindow.fxml"));
            Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loader.load());
            stage.setScene(scene);

        } catch (IOException io) {
            System.out.println("FXML Loading Error");
        }

    }

}
